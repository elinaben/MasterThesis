# Helper R functions
